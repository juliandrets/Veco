<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Picture extends Model
{
    protected $keyType = 'string';
    protected $guarded = [];
}
