<script>
  function deleteConfirm() {
    if(confirm('Está seguro de eliminar el item?'))
      return true
    else
      return false
  }
</script>