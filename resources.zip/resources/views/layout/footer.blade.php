<footer>
    <section class="bg">
        <a href="newsletter"><section id="newsletter">
            <h2>Suscribete al</h2>
            <h3>Newsletter de Veco <i class="fa fa-angle-right" aria-hidden="true"></i></h3>
        </section></a>
    </section>
    <section class="footbar">
        <p class="copy">© 2018 Veco</p>
        <ul class="redes">
            <i class="fa fa-facebook" aria-hidden="true"></i>
            <i class="fa fa-instagram" aria-hidden="true"></i>
            <i class="fa fa-linkedin" aria-hidden="true"></i>
        </ul>
        <p>powered by novativex.com</p>
    </section>
</footer>


