@extends('layout.default')

<?php $title = 'Clientes - Veco'; ?>

@section('content')

    @include('layout.header-default')

    <section id="about">
        <section id="cabecera">
            <h2 class="title">::: Showroom</h2>
        </section>

        <br><br>
        <br><br>
        <br><br>
        <p style="text-align: center; font-size: 22px; font-weight: 300">Proximamente...</p>
        <br><br>
        <br><br>
        <br><br>

    </section>

    <!-- Incluyo el footer y los script -->
    @include('layout.footer')
    @include('layout.scripts')


@endsection